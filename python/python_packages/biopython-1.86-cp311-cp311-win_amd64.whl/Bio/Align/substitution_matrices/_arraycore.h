typedef struct {
    PyObject* alphabet;
    Py_buffer mapping;
} Fields;


#define MISSING_LETTER -1
